package com.dunkcoder;

import java.sql.*;

public class InsertThenFetch {

	public static void main(String[] args) {

		String drive_class = "com.mysql.jdbc.Driver";
		String db_url = "jdbc:mysql://localhost:3306/test";
		String db_userid = "root";
		String db_password = "Passw0rd";

		Connection conn = JdbcUtil.getConnection(drive_class, db_url, db_userid, db_password);

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "insert into t_user (username) values ('san.zhang')";
			long id = JdbcUtil.insertThenFetch(conn, sql);
			JdbcUtil.println(String.format("AUTO_INCREMENT id is %sL", id));
		} catch (SQLException sqle) {
			JdbcUtil.println("SQLException main insertThenFetch failed");
		} finally {
			JdbcUtil.free(rs, pstmt);
			JdbcUtil.free(conn);
		}
	}
}